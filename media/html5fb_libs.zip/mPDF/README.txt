Upgrading
============

To upgrade from mPDF 5.7 or 5.7.1 to 5.7.2, simply upload the files to their corresponding folders, overwriting files as required.

Note: classes/barcode.php and includes/functions.php have not changed between 5.7.1 and 5.7.2 - they are included here to permit upgrading directly from 5.7 to 5.7.2


